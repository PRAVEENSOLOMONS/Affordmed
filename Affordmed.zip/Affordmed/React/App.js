import React, { useState } from 'react';
import TrainListPage from './1page';
import TrainDetailsPage from './2page';

const App = () => {
  const [currentPage, setCurrentPage] = useState('trainList');
  const [selectedTrainNumber, setSelectedTrainNumber] = useState('');

  const handleTrainClick = (trainNumber) => {
    setSelectedTrainNumber(trainNumber);
    setCurrentPage('trainDetails');
  };

  const renderPage = () => {
    if (currentPage === 'trainList') {
      return <TrainListPage onTrainClick={handleTrainClick} />;
    } else if (currentPage === 'trainDetails') {
      return <TrainDetailsPage trainNumber={selectedTrainNumber} />;
    }
  };

  return <div>{renderPage()}</div>;
};

export default App;
