import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TrainDetailsPage = ({ trainNumber }) => {
  const [train, setTrain] = useState(null);

  useEffect(() => {
    axios
      .get(`http://localhost:8000/Trains${trainNumber}`)
      .then((response) => {
        setTrain(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [trainNumber]);

  if (!train) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>{train.trainName}</h1>
      <p>Train Number: {train.trainNumber}</p>
      <p>Departure Time: {train.departureTime.hours}:{train.departureTime.minutes}</p>
      <p>Seats Available:</p>
      <ul>
        <li>Sleeper: {train.seatsAvailable.sleeper}</li>
        <li>AC: {train.seatsAvailable.ac}</li>
      </ul>
      <p>Price:</p>
      <ul>
        <li>Sleeper: {train.price.sleeper}</li>
        <li>AC: {train.price.ac}</li>
      </ul>
      <p>Delay By: {train.delayBy} minutes</p>
    </div>
  );
};

export default TrainDetailsPage;
