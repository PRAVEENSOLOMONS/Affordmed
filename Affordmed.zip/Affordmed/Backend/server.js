const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 8000;

app.use(bodyParser.json());

// Get all trains
app.get('/trains', (req, res) => {
  // Read the data from db.json
  const data = JSON.parse(fs.readFileSync('data/db.json'));
  res.json(data.Trains);
});

// Get train by train number
app.get('/trains/:trainNumber', (req, res) => {
  const { trainNumber } = req.params;

  // Read the data from db.json
  const data = JSON.parse(fs.readFileSync('data/db.json'));

  // Find the train with the specified trainNumber
  const train = data.Trains.find((t) => t.trainNumber === parseInt(trainNumber));

  if (train) {
    res.json(train);
  } else {
    res.status(404).json({ message: 'Train not found.' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
